import React, { useState } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import { TextInput, Button } from 'react-native-paper';

const styles = StyleSheet.create({
  screen: {
    backgroundColor: 'black',
    height: '100%',
    alignItems: 'center',
    paddingHorizontal: 30,
    paddingTop: 30,
  },
  title: {
    color: 'white',
    fontSize: 30,
    fontWeight: 700,
  },
  input: {
    backgroundColor: '#000000',
    width: '100%',
  },
  button: {
    width: '100%',
    marginTop: 20,
    borderRadius: 50,
    backgroundColor: '#1DE9B6',
    color: 'black',
  },
  colorBlack: {
    color: '#000000',
  },
  text: {
    color: 'white',
    marginTop: 15
  },
});

const witheTheme = {
  colors: { primary: 'white', text: 'white', placeholder: 'white' },
};

const Login = ({ navigation }) => {

  const [email, setEmail] = useState();
  const [password, setPassword] = useState();

  const goToRegister = () => {
    navigation.navigate('Register');
  }

  return (
    <View style={styles.screen}>
        <Text style={styles.title}>groovy</Text>
        <TextInput
        label="Email"
        value={email}
        style={styles.input}
        theme={witheTheme}
        underlineColor="white"
      />
      <TextInput
        label="Password"
        value={password}
        style={styles.input}
        theme={witheTheme}
        underlineColor="white"
      />
      <Button
        icon="account"
        mode="contained"
        style={styles.button}
        labelStyle={styles.colorBlack}
        color="black"
        onPress={() => console.log('Pressed')}>
        Let's go
      </Button>
      <Text style={styles.text}>Forgot Password</Text>
      <Text style={styles.text} onPress={goToRegister}>Create Account</Text>
    </View>
  );
};

export default Login;
