import React from 'react';
import {Text, StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  title: {
    color: 'gren',
    fontSize: 30,
    fontWeight: 700,

    
  },
});

const Title = () => {
   return <Text style={styles.title}>groovy Login</Text>
};

export default Title;